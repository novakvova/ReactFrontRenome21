import React, { Component } from 'react'

export class Home extends Component {
    render() {
        return (
            <div>
                <h1>Головна сторінка</h1>
            </div>
        )
    }
}

export default Home
